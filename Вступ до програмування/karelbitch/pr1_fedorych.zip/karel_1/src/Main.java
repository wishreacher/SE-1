import stanford.karel.Karel;

public class Main extends Karel {
    public void run(){
       move();
       pickBeeper();
       turnLeft();
       move();
       move();
       move();
       move();
       turnLeft();
       turnLeft();
       turnLeft();
       move();
       move();
       putBeeper();
       turnLeft();
       turnLeft();
       move();
       move();
       move();
       turnLeft();
       move();
       move();
       move();
       move();
       turnLeft();
    }
}